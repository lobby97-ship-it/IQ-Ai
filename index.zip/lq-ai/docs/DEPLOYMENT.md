# Deployment

## Vercel

Create a Vercel project pointing at `apps/web`. Set `NEXT_PUBLIC_API_URL` to the public API URL.

## Railway / Fly.io

Deploy `apps/api` as a Node service. Set all server environment variables from `.env.example`. Run database migrations during release.

## Docker

`docker compose up -d postgres redis minio`

The included compose file is for development. Use managed PostgreSQL/Redis/object storage for production.

## EAS

From `apps/mobile`, install Expo tooling and configure the `com.lqai.app` identifier in `app.json`. Build with EAS after setting `EXPO_PUBLIC_API_URL`.
