# API surface

- `GET /health` — service health
- `POST /auth/register` — create an account
- `POST /auth/login` — login
- `POST /auth/refresh` — rotate access token
- `POST /auth/logout` — revoke refresh session
- `GET /conversations` — authenticated history
- `GET /conversations/:id/messages` — authenticated messages
- `POST /chat/stream` — SSE streaming chat; guest mode is supported with development/provider limits
- `POST /conversations/:id/archive` — archive a conversation
- `POST /messages/:id/feedback` — thumbs up/down feedback
- `GET/POST/DELETE /memories` — memory controls
- `GET/POST /projects` — project management

The API uses JSON error envelopes and Zod validation for public request contracts.
