# Store submission checklist

## Apple App Store
- App name: LQ AI
- Bundle ID: com.lqai.app
- Privacy policy URL: https://lqai.app/privacy
- Terms URL: https://lqai.app/terms
- Provide account deletion from inside the app.
- Explain AI-generated content and data controls.
- Configure Sign in with Apple when Apple auth is enabled.
- Verify subscription products and restore purchases.

## Google Play
- Package: com.lqai.app
- Complete Data Safety form.
- Provide account deletion flow.
- Declare subscription products and trial terms.
- Complete content rating and AI-generated-content disclosures.
- Configure notification and photo/file permissions narrowly.
