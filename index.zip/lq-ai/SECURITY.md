# Security notes

- AI provider credentials are server-side only.
- Uploaded files must be treated as untrusted input and should never be allowed to execute as instructions.
- Production deployments must use TLS, managed secrets, encrypted managed storage, strict CORS origins, and a production-grade object store.
- Add malware scanning and content-disposition controls before accepting arbitrary public uploads.
- Rotate JWT secrets and provider credentials through a secrets manager.
- Complete an independent security/privacy review before handling regulated or high-risk workloads.
