# LQ AI

LQ AI is a full-stack AI assistant monorepo with a Next.js web client, Fastify API, Expo mobile client, PostgreSQL/pgvector, Redis, and a provider-agnostic AI gateway.

## Stack

- Web: Next.js 15, TypeScript, Tailwind CSS
- API: Fastify, Zod, JWT, SSE
- Data: PostgreSQL + pgvector, Redis, BullMQ
- Mobile: Expo + React Native
- AI: Anthropic adapter with model routing
- Monorepo: pnpm + Turborepo

## Local development

1. Copy `.env.example` to `.env`.
2. Start infrastructure: `docker compose up -d postgres redis minio`
3. Install: `pnpm install`
4. Run migrations: `pnpm --filter @lq-ai/api db:migrate`
5. Seed: `pnpm --filter @lq-ai/api db:seed`
6. Start web + API: `pnpm dev`
7. Web: http://localhost:3000
8. API health: http://localhost:4000/health

With no Anthropic key, the API uses a local development responder. Add `ANTHROPIC_API_KEY` to use Claude.

## Build

`pnpm build`

## Production

The web can deploy to Vercel. The API should run on Railway/Fly.io or another Node host. PostgreSQL, Redis, and S3-compatible storage should be managed services in production. Mobile builds use EAS.

See `docs/DEPLOYMENT.md`, `docs/STORE_CHECKLISTS.md`, and `ROADMAP.md`.
