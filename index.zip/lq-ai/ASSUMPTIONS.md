# LQ AI — Assumptions

1. The canonical repository is a pnpm/Turborepo monorepo with Next.js web, Fastify API, Expo mobile, and shared TypeScript packages.
2. PostgreSQL is the source of truth. pgvector is enabled in the migration for retrieval embeddings.
3. Claude through Anthropic is the default AI provider. Provider adapters are server-only; no API key is exposed to clients.
4. A local deterministic assistant response is used when ANTHROPIC_API_KEY is absent so the repository can boot and be developed without paid credentials.
5. Email/password auth is fully local. Google, Apple, Stripe, RevenueCat, S3, search, Sentry, and PostHog are adapter-ready and enabled only when their credentials are supplied.
6. The first implementation uses HttpOnly JWT access/refresh cookies for the web and bearer tokens for mobile. Refresh rotation is persisted in sessions.
7. Guest mode is intentionally rate-limited and stored client-side until an account is created.
8. The product's visual language is original: deep ink backgrounds, electric violet/blue accents, high-contrast text, large radii, and restrained motion.
9. The first production slice prioritizes reliable chat, branching, history, attachments metadata, memory, projects, and tool registry. Full external-provider onboarding flows require real provider credentials and domain verification.
10. The domain is lqai.app and package/bundle identifier is com.lqai.app.
11. No analytics event contains message text, uploaded document contents, or model prompts.
12. Age gate is 13+. Country-specific legal review is still required before public launch.
