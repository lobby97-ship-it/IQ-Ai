import type {Config} from 'tailwindcss';
const config:Config={darkMode:['class'],content:['./app/**/*.{ts,tsx}','./components/**/*.{ts,tsx}'],theme:{extend:{colors:{ink:'#070812',panel:'#0d1020',muted:'#969bb5',brand:'#7c5cff',cyan:'#55d6ff',line:'rgba(255,255,255,.09)'}}}};export default config;
