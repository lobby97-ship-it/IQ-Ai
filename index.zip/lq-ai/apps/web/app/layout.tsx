import './globals.css';import type {Metadata} from 'next';
export const metadata:Metadata={title:'LQ AI — Your intelligent assistant',description:'LQ AI is a powerful, calm AI assistant for chat, writing, coding, files and ideas.',metadataBase:new URL('https://lqai.app')};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
