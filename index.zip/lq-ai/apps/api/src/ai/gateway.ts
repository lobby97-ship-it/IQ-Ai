import Anthropic from '@anthropic-ai/sdk';
import {config} from '../lib/config.js';
import type {ModelId} from '@lq-ai/shared';
export type ChatTurn={role:'user'|'assistant';content:string};
export interface Gateway{stream(input:{model:ModelId;system:string;messages:ChatTurn[]}):AsyncGenerator<string>}
const local=async function*({messages}:{model:ModelId;system:string;messages:ChatTurn[]}){const last=messages.at(-1)?.content||'';const answer=`LQ AI is running in local development mode.\n\nYou said: **${last.slice(0,4000)}**\n\nAdd ANTHROPIC_API_KEY to .env to enable Claude-powered responses.`;for(const word of answer.split(/(\s+)/)){await new Promise(r=>setTimeout(r,8));yield word;}};
export const gateway:Gateway={async *stream({model,system,messages}){if(!config.anthropicKey){yield* local({model,system,messages});return;}const client=new Anthropic({apiKey:config.anthropicKey});const stream=client.messages.stream({model:config.models[model],max_tokens:model==='reasoning'?8192:4096,system,messages:messages.map(m=>({role:m.role,content:m.content}))});for await(const event of stream){if(event.type==='content_block_delta'&&event.delta.type==='text_delta')yield event.delta.text;}}};
