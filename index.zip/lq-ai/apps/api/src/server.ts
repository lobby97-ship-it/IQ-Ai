import Fastify from 'fastify';import cookie from '@fastify/cookie';import cors from '@fastify/cors';import jwt from '@fastify/jwt';import rateLimit from '@fastify/rate-limit';import sensible from '@fastify/sensible';import {config} from './lib/config.js';import {registerAuth} from './auth/auth.js';import {authRoutes} from './routes/auth.js';import {chatRoutes} from './routes/chat.js';import {memoryRoutes} from './routes/memory.js';import {projectRoutes} from './routes/projects.js';
const app=Fastify({logger:true});
await app.register(sensible);await app.register(cookie);await app.register(cors,{origin:[config.appUrl,'http://localhost:19006'],credentials:true});await app.register(jwt,{secret:config.jwtSecret});await app.register(rateLimit,{max:120,timeWindow:'1 minute'});await registerAuth(app);
app.get('/health',async()=>({ok:true,name:'LQ AI API',version:'1.0.0',time:new Date().toISOString()}));
await authRoutes(app);await chatRoutes(app);await memoryRoutes(app);await projectRoutes(app);
app.setErrorHandler((err,req,reply)=>{req.log.error(err);const status=(err as any).statusCode||500;reply.code(status).send({error:{message:status>=500?'Internal server error':err.message,code:status===400?'BAD_REQUEST':status===401?'UNAUTHORIZED':'REQUEST_ERROR'}})});
app.listen({port:config.port,host:'0.0.0.0'}).then(()=>app.log.info(`LQ AI API listening on ${config.port}`));
