import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import type {FastifyInstance,FastifyRequest} from 'fastify';
import {query} from '../db/index.js';
export async function registerAuth(app:FastifyInstance){app.decorateRequest('user',null);app.decorate('authenticate',async(req:FastifyRequest)=>{try{await req.jwtVerify();}catch{throw app.httpErrors.unauthorized('Authentication required');}});}
export async function hashPassword(p:string){return bcrypt.hash(p,12)}
export async function verifyPassword(p:string,h:string){return bcrypt.compare(p,h)}
export function hashToken(t:string){return crypto.createHash('sha256').update(t).digest('hex')}
export async function createSession(userId:string){const refresh=crypto.randomBytes(48).toString('base64url');await query('INSERT INTO sessions(user_id,refresh_hash,expires_at) VALUES($1,$2,now()+interval \'30 days\')',[userId,hashToken(refresh)]);return refresh}
