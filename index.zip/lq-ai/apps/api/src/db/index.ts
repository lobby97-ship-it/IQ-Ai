import pg from 'pg';
const {Pool}=pg;
export const pool=new Pool({connectionString:process.env.DATABASE_URL||'postgresql://lqai:lqai@localhost:5432/lqai'});
export async function query<T=any>(text:string,params:any[]=[]){const r=await pool.query<T>(text,params);return r.rows;}
