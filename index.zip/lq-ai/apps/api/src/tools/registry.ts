export type ToolDefinition={name:string;description:string;inputSchema:Record<string,unknown>;execute:(input:unknown)=>Promise<unknown>};
const calculator:ToolDefinition={name:'calculator',description:'Evaluate basic arithmetic expressions.',inputSchema:{type:'object',properties:{expression:{type:'string'}}},execute:async(input:any)=>{const expression=String(input?.expression||'').replace(/[^0-9+\-*/().%\s]/g,'');if(!expression)throw new Error('Invalid expression');return {expression,result:Function(`"use strict";return (${expression})`)()};}};
export const tools:ToolDefinition[]=[calculator];
export function getTool(name:string){return tools.find(t=>t.name===name)}
