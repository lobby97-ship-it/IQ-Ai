import fs from 'node:fs/promises';import path from 'node:path';import {pool} from '../src/db/index.js';
const dir=path.resolve('apps/api/migrations');const files=(await fs.readdir(dir)).filter(x=>x.endsWith('.sql')).sort();for(const file of files){const sql=await fs.readFile(path.join(dir,file),'utf8');await pool.query(sql);console.log(`applied ${file}`);}await pool.end();
