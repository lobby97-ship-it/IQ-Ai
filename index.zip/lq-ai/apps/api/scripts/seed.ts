import {pool} from '../src/db/index.js';
await pool.query(`insert into users(email,password_hash,display_name) values('demo@lqai.app',crypt('LQAI-demo-2026',gen_salt('bf')),'LQ AI Demo') on conflict(email) do nothing`);console.log('seeded demo account: demo@lqai.app / LQAI-demo-2026');await pool.end();
