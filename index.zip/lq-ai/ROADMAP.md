# LQ AI Roadmap

## Phase 1 — foundation
- Monorepo, shared contracts, API, database migration, authentication, streaming chat, responsive web shell, Expo shell.

## Phase 2 — assistant depth
- Web search citations, Python sandbox jobs, image generation adapter, richer file extraction and pgvector retrieval.

## Phase 3 — product systems
- Projects, assistants, durable memory controls, share links, scheduled tasks, voice, push notifications.

## Phase 4 — monetization and launch
- Stripe, RevenueCat, usage metering, trials, entitlement sync, App Store/Play Store release.

## Phase 5 — hardening
- Provider failover, load testing, tracing, abuse detection, security review, accessibility audit, privacy/legal review.
