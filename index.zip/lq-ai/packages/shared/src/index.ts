import { z } from 'zod';
export const ModelId = z.enum(['fast','smart','reasoning']);
export type ModelId = z.infer<typeof ModelId>;
export const MessageRole = z.enum(['user','assistant','system','tool']);
export type MessageRole = z.infer<typeof MessageRole>;
export const ChatRequest = z.object({conversationId:z.string().uuid().optional(),message:z.string().min(1).max(100000),model:ModelId.default('fast'),temporary:z.boolean().default(false),parentId:z.string().uuid().nullable().optional(),attachments:z.array(z.string().uuid()).default([])});
export type ChatRequest = z.infer<typeof ChatRequest>;
export type StreamEvent = {type:'delta';text:string}|{type:'done';messageId:string;conversationId:string}|{type:'error';message:string};
