import * as React from 'react';import {Slot} from '@radix-ui/react-slot';import {cn} from './utils.js';
export {cn};
export function Button({asChild=false,className='',...props}:React.ButtonHTMLAttributes<HTMLButtonElement>&{asChild?:boolean}){const C=asChild?Slot:'button';return <C className={cn('inline-flex min-h-11 items-center justify-center rounded-xl px-4 text-sm font-medium transition hover:opacity-90 disabled:pointer-events-none disabled:opacity-50',className)} {...props}/>}
